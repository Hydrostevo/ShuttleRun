#ifndef WEBPAGE_H
#define WEBPAGE_H

const char index_html[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html>
<head>
  <title>Shuttle Run Status</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 20px;
      background: #f0f0f0;
    }
    h1 { text-align: center; }
    h2 { 
      text-align: center;
      color: #2c3e50;
      margin-top: 30px;
    }
    .container {
      max-width: 600px;
      margin: 0 auto;
      background: white;
      padding: 20px;
      border-radius: 10px;
      border: outset;
    }
    .cone-grid {
      display: grid;
      grid-template-columns: repeat(5, 1fr);
      gap: 5px;
      margin-top: 20px;
      padding: 15px;
      background: #f9f9f9;
      border-radius: 8px;
      border: 2px solid #ddd;
    }
    .conecontainer {
      max-width: 80px;
      margin: 0 auto;
      background: white;
      padding: 10px;
      border-radius: 10px;
      border: outset;    
    }
    .status {
      display: flex;
      justify-content: center;
      margin: 10px 0;
      padding: 15px;
      border-radius: 5px;
      font-weight: bold;
      border: outset;
    }
    .idle { background: #e3f2fd; }
    .running { background: #fff3e0; }
    .success { background: #e8f5e8; }
    .failed { background: #ffebee; }
    .connection-info {
      text-align: center;
      margin: 15px 0;
      padding: 10px;
      background: #f5f5f5;
      border-radius: 5px;
      border: inset;
    }
    .slaves, .master {
      display: flex;
      justify-content: space-around;
      margin-top: 5px;
    }
    .slave, .master {
      text-align: center;
      font-size: 1rem;
    }
    .slave span, .master span {
      display: block;
      margin-top: 5px;
      font-size: 0.9rem;
    }
    .reset-btn, .battery-btn {
      display: block;
      width: 200px;
      margin: 20px auto;
      padding: 15px;
      font-size: 1.1rem;
      font-weight: bold;
      color: white;
      background: #ff5722;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      box-shadow: 0 3px 6px rgba(0,0,0,0.2);
    }
    .battery-btn {
      background: #3498db;
    }
    .battery-btn:hover {
      background: #2980b9;
    }
    .reset-btn:hover {
      background: #e64a19;
    }
  </style>
  <script>
    // Create cone SVG dynamically
    function createConeSVG(id, gradientId, label) {
      return `
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="${id === 'master' ? 70 : 50}" height="${id === 'master' ? 70 : 50}">
          <defs>
            <linearGradient id="gradient-${gradientId}" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" style="stop-color:#4d004d;stop-opacity:1" />
              <stop offset="50%" style="stop-color:#800080;stop-opacity:1" />
              <stop offset="100%" style="stop-color:#4d004d;stop-opacity:1" />
            </linearGradient>
            <radialGradient id="shine-${gradientId}" cx="40%" cy="30%">
              <stop offset="0%" style="stop-color:#ffffff;stop-opacity:0.4" />
              <stop offset="100%" style="stop-color:#ffffff;stop-opacity:0" />
            </radialGradient>
          </defs>
          <ellipse cx="32" cy="59" rx="20" ry="3" fill="#333" opacity="0.3"/>
          <path d="M14 58h36l1-4H13z" fill="#e0e0e0"/>
          <ellipse cx="32" cy="54" rx="18.5" ry="2" fill="#fff" opacity="0.2"/>
          <path class="cone-body" d="M20 52h24l-8-36h-8z" fill="url(#gradient-${gradientId})" stroke="#4d004d" stroke-width="0.5"/>
          <path d="M20 52h24l-8-36h-8z" fill="url(#shine-${gradientId})" opacity="0.6"/>
          <path d="M22 45h20l-2-8H24z" fill="#fff" opacity="0.8"/>
          <path d="M25 30h14l-2-8H27z" fill="#fff" opacity="0.8"/>
          <ellipse cx="32" cy="16" rx="6" ry="1.5" fill="#4d004d"/>
          <path d="M28 6h8l2 10h-12z" fill="url(#gradient-${gradientId})" stroke="#4d004d" stroke-width="0.5"/>
          <ellipse cx="32" cy="6" rx="4" ry="2" fill="#999"/>
        </svg>
        <span class="label">${label}</span>
      `;
    }

    // Initialize cones on page load
    window.onload = function() {
      // Set A cones
      document.getElementById('masterA').innerHTML = createConeSVG('master', 'masterA', 'Master A');
      document.getElementById('slave2').innerHTML = createConeSVG('slave', 'slave2', 'Cone 1');
      document.getElementById('slave3').innerHTML = createConeSVG('slave', 'slave3', 'Cone 2');
      document.getElementById('slave4').innerHTML = createConeSVG('slave', 'slave4', 'Cone 3');
      document.getElementById('slave5').innerHTML = createConeSVG('slave', 'slave5', 'Cone 4');
      
      // Set B cones
      document.getElementById('masterB').innerHTML = createConeSVG('master', 'masterB', 'Master B');
      document.getElementById('slave6').innerHTML = createConeSVG('slave', 'slave6', 'Cone 5');
      document.getElementById('slave7').innerHTML = createConeSVG('slave', 'slave7', 'Cone 6');
      document.getElementById('slave8').innerHTML = createConeSVG('slave', 'slave8', 'Cone 7');
      document.getElementById('slave9').innerHTML = createConeSVG('slave', 'slave9', 'Cone 8');
    };

    setInterval(() => fetch('/status').then(r => r.json()).then(updateStatus), 1000);

    function updateStatus(data) {
      const stateElem = document.getElementById('gameState');
      stateElem.textContent = data.state;
      stateElem.className = 'status ' + data.state.toLowerCase();

      document.getElementById('timer').textContent = data.timer + 's';
      document.getElementById('completionTime').textContent = data.completionTime + 's';
      
      if (data.connectedCount !== undefined) {
        document.getElementById('connectedCount').textContent = data.connectedCount;
      }

      // Update Master A cone color
      let masterAGradient = document.querySelector('#masterA .cone-body');
      if (masterAGradient) {
        let color;
        if (data.state === "RUNNING") color = '#ffa500';
        else if (data.state === "SUCCESS") color = '#00ff00';
        else if (data.state === "FAILED") color = '#ff0000';
        else color = '#800080';
        let darkColor = adjustBrightness(color, -40);
        masterAGradient.setAttribute('fill', `url(#gradient-${color.substring(1)})`);
        updateGradient(`gradient-${color.substring(1)}`, color, darkColor, masterAGradient);
      }

      // Update Master B cone color
      let masterBGradient = document.querySelector('#masterB .cone-body');
      if (masterBGradient) {
        let color;
        if (data.state === "RUNNING") color = '#ffa500';
        else if (data.state === "SUCCESS") color = '#00ff00';
        else if (data.state === "FAILED") color = '#ff0000';
        else color = '#800080';
        let darkColor = adjustBrightness(color, -40);
        masterBGradient.setAttribute('fill', `url(#gradient-${color.substring(1)})`);
        updateGradient(`gradient-${color.substring(1)}`, color, darkColor, masterBGradient);
      }

      // Update slave cones (2-9)
      for (let i = 2; i <= 9; i++) {
        let coneBody = document.querySelector('#slave' + i + ' .cone-body');
        if (coneBody && data.slavesState && data.slavesState[i]) {
          let state = data.slavesState[i];
          let color = state === 'pressed' ? '#00ff00' : state === 'error' ? '#ff0000' : '#800080';
          let darkColor = adjustBrightness(color, -40);
          coneBody.setAttribute('fill', `url(#gradient-${color.substring(1)})`);
          updateGradient(`gradient-${color.substring(1)}`, color, darkColor, coneBody);
        }
      }
    }
    
    function adjustBrightness(color, amount) {
      let num = parseInt(color.replace("#",""), 16);
      let r = Math.max(0, Math.min(255, (num >> 16) + amount));
      let g = Math.max(0, Math.min(255, ((num >> 8) & 0x00FF) + amount));
      let b = Math.max(0, Math.min(255, (num & 0x0000FF) + amount));
      return "#" + ((r << 16) | (g << 8) | b).toString(16).padStart(6, '0');
    }
    
    function updateGradient(id, color1, color2, element) {
      // Find the SVG parent of the element
      let svg = element.closest('svg');
      if (!svg) return;
      
      let defs = svg.querySelector('defs');
      if (!defs) {
        defs = document.createElementNS("http://www.w3.org/2000/svg", "defs");
        svg.insertBefore(defs, svg.firstChild);
      }
      
      let grad = svg.querySelector('#' + id);
      if (!grad) {
        grad = document.createElementNS("http://www.w3.org/2000/svg", "linearGradient");
        grad.setAttribute('id', id);
        grad.setAttribute('x1', '0%');
        grad.setAttribute('y1', '0%');
        grad.setAttribute('x2', '100%');
        grad.setAttribute('y2', '0%');
        
        let stop1 = document.createElementNS("http://www.w3.org/2000/svg", "stop");
        stop1.setAttribute('offset', '0%');
        stop1.setAttribute('style', `stop-color:${color2};stop-opacity:1`);
        
        let stop2 = document.createElementNS("http://www.w3.org/2000/svg", "stop");
        stop2.setAttribute('offset', '50%');
        stop2.setAttribute('style', `stop-color:${color1};stop-opacity:1`);
        
        let stop3 = document.createElementNS("http://www.w3.org/2000/svg", "stop");
        stop3.setAttribute('offset', '100%');
        stop3.setAttribute('style', `stop-color:${color2};stop-opacity:1`);
        
        grad.appendChild(stop1);
        grad.appendChild(stop2);
        grad.appendChild(stop3);
        defs.appendChild(grad);
      } else {
        grad.children[0].setAttribute('style', `stop-color:${color2};stop-opacity:1`);
        grad.children[1].setAttribute('style', `stop-color:${color1};stop-opacity:1`);
        grad.children[2].setAttribute('style', `stop-color:${color2};stop-opacity:1`);
      }
    }
  </script>
</head>
<body>
  <div class="container">
    <h1><u>Shuttle Run Game</u></h1>

    <!-- Set A -->
    <h2>Set A</h2>
    <div class="cone-grid">
      <!-- Master Cone A -->
      <div class="conecontainer">
        <div class="master">
          <div id="masterA"></div>
        </div>
      </div>
      <!-- Slave Cones 2-5 -->
      <div class="conecontainer">
        <div class="slaves">
          <div id="slave2" class="slave"></div>
        </div>
      </div>
      <div class="conecontainer">
        <div class="slaves">
          <div id="slave3" class="slave"></div>
        </div>
      </div>
      <div class="conecontainer">
        <div class="slaves">
          <div id="slave4" class="slave"></div>
        </div>
      </div>
      <div class="conecontainer">
        <div class="slaves">
          <div id="slave5" class="slave"></div>
        </div>
      </div>
    </div>
 
    <!-- Status + Timers for Set A -->
    <div id="gameState" class="status idle">READY</div>
    <div style="text-align: center;">Time Remaining: <span id="timer">--</span></div>
    <div style="text-align: center;">Completion Time: <span id="completionTime">--</span></div>
    
    <!-- Set B -->
    <h2>Set B</h2>
    <div class="cone-grid">
      <!-- Master Cone B -->
      <div class="conecontainer">
        <div class="master">
          <div id="masterB"></div>
        </div>
      </div>
      <!-- Slave Cones 6-9 -->
      <div class="conecontainer">
        <div class="slaves">
          <div id="slave6" class="slave"></div>
        </div>
      </div>
      <div class="conecontainer">
        <div class="slaves">
          <div id="slave7" class="slave"></div>
        </div>
      </div>
      <div class="conecontainer">
        <div class="slaves">
          <div id="slave8" class="slave"></div>
        </div>
      </div>
      <div class="conecontainer">
        <div class="slaves">
          <div id="slave9" class="slave"></div>
        </div>
      </div>
    </div>
    
    <hr>
      
    <!-- Reset Button -->
    <button class="reset-btn" onclick="resetGame()">RESET GAME</button>
    
    <!-- Battery Management Button -->
    <button class="battery-btn" onclick="window.location.href='/batteries'">Battery Management</button>

    <!-- Connection Info -->
    <div class="connection-info">
      <strong>Connected Slaves: <span id="connectedCount">0</span>/8</strong>
    </div>
  </div>
</body>
</html>
)rawliteral";

#endif