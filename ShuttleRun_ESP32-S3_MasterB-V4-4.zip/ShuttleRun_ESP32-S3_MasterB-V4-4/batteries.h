#ifndef BATTERIES__H
#define BATTERIES_H

const char batteries_html[] PROGMEM = R"rawliteral(

<!DOCTYPE html>
<html>
<head>
  <title>Battery Management</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 20px;
      background: #f0f0f0;
    }
    h1 { 
      text-align: center;
      color: #2c3e50;
    }
    h2 {
      color: #34495e;
      border-bottom: 2px solid #3498db;
      padding-bottom: 10px;
      margin-top: 30px;
    }
    .container {
      max-width: 1200px;
      margin: 0 auto;
      background: white;
      padding: 20px;
      border-radius: 10px;
      border: outset;
    }
    
    .system-section {
      margin-bottom: 40px;
      padding: 20px;
      background: #f9f9f9;
      border-radius: 8px;
      border: 2px solid #ddd;
    }
    
    .battery-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
      gap: 20px;
      margin-top: 20px;
    }
    
    .battery-card {
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 20px;
      background: white;
      border-radius: 8px;
      box-shadow: 0 4px 6px rgba(0,0,0,0.1);
      border: 2px solid #ddd;
      transition: transform 0.2s;
    }
    
    .battery-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 6px 12px rgba(0,0,0,0.15);
    }
    
    .battery-card.master {
      border-color: #9b59b6;
      background: linear-gradient(to bottom, #fff 0%, #f8f4fb 100%);
    }
    
    .battery-card.slave {
      border-color: #3498db;
      background: linear-gradient(to bottom, #fff 0%, #f4f8fb 100%);
    }
    
    .battery-card.critical {
      border-color: #e74c3c;
      animation: pulse 2s infinite;
    }
    
    @keyframes pulse {
      0%, 100% { box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
      50% { box-shadow: 0 4px 20px rgba(231,76,60,0.5); }
    }
    
    .device-label {
      font-size: 16px;
      font-weight: bold;
      color: #2c3e50;
      margin-bottom: 5px;
      text-align: center;
    }
    
    .device-id {
      font-size: 12px;
      color: #7f8c8d;
      margin-bottom: 15px;
    }
    
    .battery-container {
      position: relative;
      display: inline-block;
      margin: 10px 0;
      width: 50px;
      height: 100px;
    }
    
    .battery-body {
      position: absolute;
      left: 50%;
      transform: translateX(-50%);
      bottom: 0;
      width: 40px;
      height: 85px;
      border: 4px solid #2c3e50;
      border-radius: 6px;
      background: #ecf0f1;
      overflow: hidden;
      box-shadow: inset 0 2px 10px rgba(0,0,0,0.15);
    }
    
    .battery-tip {
      position: absolute;
      left: 50%;
      transform: translateX(-50%);
      top: 0;
      width: 18px;
      height: 8px;
      background: #2c3e50;
      border-radius: 4px 4px 0 0;
    }
    
    .battery-level {
      position: absolute;
      bottom: 0;
      width: 100%;
      background: linear-gradient(to top, #4CAF50 0%, #8BC34A 100%);
      transition: height 0.3s ease, background 0.3s ease;
      box-shadow: inset 0 0 15px rgba(255,255,255,0.3);
    }
    
    .battery-shine {
      position: absolute;
      top: 0;
      left: 4px;
      right: 4px;
      height: 40%;
      background: linear-gradient(to bottom, rgba(255,255,255,0.6), transparent);
      border-radius: 3px;
      pointer-events: none;
    }
    
    .percentage-display {
      font-size: 24px;
      font-weight: bold;
      color: #2c3e50;
      margin-top: 10px;
    }
    
    .voltage-display {
      font-size: 14px;
      color: #7f8c8d;
      margin-top: 5px;
    }
    
    .status-badge {
      margin-top: 10px;
      padding: 5px 15px;
      border-radius: 20px;
      font-size: 12px;
      font-weight: bold;
      text-transform: uppercase;
    }
    
    .status-good {
      background: #d4edda;
      color: #155724;
    }
    
    .status-warning {
      background: #fff3cd;
      color: #856404;
    }
    
    .status-critical {
      background: #f8d7da;
      color: #721c24;
    }
    
    .status-disconnected {
      background: #e2e3e5;
      color: #383d41;
    }
    
    .summary-panel {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 15px;
      margin-bottom: 30px;
    }
    
    .summary-card {
      padding: 20px;
      background: white;
      border-radius: 8px;
      border: 2px solid #ddd;
      text-align: center;
    }
    
    .summary-title {
      font-size: 12px;
      color: #7f8c8d;
      text-transform: uppercase;
      margin-bottom: 10px;
    }
    
    .summary-value {
      font-size: 32px;
      font-weight: bold;
      color: #2c3e50;
    }
    
    .last-update {
      text-align: center;
      color: #7f8c8d;
      font-size: 12px;
      margin-top: 20px;
    }
    
    .refresh-btn, .battery-btn {
      display: block;
      width: 200px;
      margin: 20px auto;
      padding: 12px;
      font-size: 1rem;
      font-weight: bold;
      color: white;
      background: #3498db;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      box-shadow: 0 3px 6px rgba(0,0,0,0.2);
      transition: background 0.3s;
    }
    
    .refresh-btn:hover, .battery-btn:hover {
      background: #2980b9;
    }
    
    .battery-btn {
      background: #95a5a6;
    }
    
    .battery-btn:hover {
      background: #7f8c8d;
    }
  </style>
  <script>
    // Auto-refresh every 500ms (0.5 seconds) for faster updates
    setInterval(() => fetchBatteryData(), 500);
    
    // Initial load
    window.onload = fetchBatteryData;
    
    function fetchBatteryData() {
      // Fetch real data from /status endpoint with timeout
      fetch('/status', { 
        method: 'GET',
        cache: 'no-cache'
      })
        .then(response => {
          if (!response.ok) throw new Error('Network response was not ok');
          return response.json();
        })
        .then(data => {
          if (data.batteries) {
            processAndDisplayData(data);
          }
        })
        .catch(error => {
          console.error('Error fetching battery data:', error);
        });
    }
    
    function processAndDisplayData(data) {
      // Convert the batteries object to the format needed for display
      const voltageData = {
        system1: {
          master: { 
            id: 1, 
            voltage: parseFloat(data.batteries['1'] || 0),
            connected: data.connectedCount !== undefined && data.batteries['1'] !== undefined
          },
          slaves: [
            { 
              id: 2, 
              voltage: parseFloat(data.batteries['2'] || 0),
              connected: data.slavesState && data.slavesState[2] !== undefined
            },
            { 
              id: 3, 
              voltage: parseFloat(data.batteries['3'] || 0),
              connected: data.slavesState && data.slavesState[3] !== undefined
            },
            { 
              id: 4, 
              voltage: parseFloat(data.batteries['4'] || 0),
              connected: data.slavesState && data.slavesState[4] !== undefined
            },
            { 
              id: 5, 
              voltage: parseFloat(data.batteries['5'] || 0),
              connected: data.slavesState && data.slavesState[5] !== undefined
            }
          ]
        },
        system2: {
          master: { 
            id: 6, 
            voltage: parseFloat(data.batteries['6'] || 0),
            connected: false  // Set to true if you have a second system
          },
          slaves: [
            { 
              id: 7, 
              voltage: parseFloat(data.batteries['7'] || 0),
              connected: false
            },
            { 
              id: 8, 
              voltage: parseFloat(data.batteries['8'] || 0),
              connected: false
            },
            { 
              id: 9, 
              voltage: parseFloat(data.batteries['9'] || 0),
              connected: false
            },
            { 
              id: 10, 
              voltage: parseFloat(data.batteries['10'] || 0),
              connected: false
            }
          ]
        }
      };
      
      updateDisplay(voltageData);
    }
    
    function calculatePercentage(voltage) {
      // Li-ion battery: 3.0V (0%) to 4.2V (100%)
      return Math.min(100, Math.max(0, ((voltage - 3.0) / 1.2) * 100));
    }
    
    function getStatusClass(percentage, connected) {
      if (!connected) return 'status-disconnected';
      if (percentage > 50) return 'status-good';
      if (percentage > 20) return 'status-warning';
      return 'status-critical';
    }
    
    function getStatusText(percentage, connected) {
      if (!connected) return 'Disconnected';
      if (percentage > 50) return 'Good';
      if (percentage > 20) return 'Low';
      return 'Critical';
    }
    
    function getBatteryColor(percentage) {
      if (percentage > 50) return 'linear-gradient(to top, #4CAF50 0%, #8BC34A 100%)';
      if (percentage > 20) return 'linear-gradient(to top, #FFA726 0%, #FFB74D 100%)';
      return 'linear-gradient(to top, #EF5350 0%, #E57373 100%)';
    }
    
    function updateDeviceBattery(deviceId, voltage, connected) {
      const percentage = calculatePercentage(voltage);
      
      // Update battery level
      const batteryLevel = document.getElementById(`batteryLevel-${deviceId}`);
      if (batteryLevel) {
        batteryLevel.style.height = connected ? percentage + '%' : '0%';
        batteryLevel.style.background = getBatteryColor(percentage);
      }
      
      // Update percentage display
      const percentageDisplay = document.getElementById(`percentage-${deviceId}`);
      if (percentageDisplay) {
        percentageDisplay.textContent = connected ? Math.round(percentage) + '%' : '--';
      }
      
      // Update voltage display
      const voltageDisplay = document.getElementById(`voltage-${deviceId}`);
      if (voltageDisplay) {
        voltageDisplay.textContent = connected ? voltage.toFixed(2) + 'V' : '--';
      }
      
      // Update status badge
      const statusBadge = document.getElementById(`status-${deviceId}`);
      if (statusBadge) {
        statusBadge.className = 'status-badge ' + getStatusClass(percentage, connected);
        statusBadge.textContent = getStatusText(percentage, connected);
      }
      
      // Update card critical class
      const card = document.getElementById(`card-${deviceId}`);
      if (card) {
        if (connected && percentage <= 20) {
          card.classList.add('critical');
        } else {
          card.classList.remove('critical');
        }
      }
    }
    
    function updateDisplay(data) {
      // Update System 1
      updateDeviceBattery(data.system1.master.id, data.system1.master.voltage, data.system1.master.connected);
      data.system1.slaves.forEach(slave => {
        updateDeviceBattery(slave.id, slave.voltage, slave.connected);
      });
      
      // Update System 2
      updateDeviceBattery(data.system2.master.id, data.system2.master.voltage, data.system2.master.connected);
      data.system2.slaves.forEach(slave => {
        updateDeviceBattery(slave.id, slave.voltage, slave.connected);
      });
      
      // Calculate summary stats
      const allDevices = [
        data.system1.master,
        ...data.system1.slaves,
        data.system2.master,
        ...data.system2.slaves
      ];
      
      const connectedDevices = allDevices.filter(d => d.connected).length;
      const criticalDevices = allDevices.filter(d => d.connected && calculatePercentage(d.voltage) <= 20).length;
      const connectedVoltages = allDevices.filter(d => d.connected && d.voltage > 0);
      const avgVoltage = connectedVoltages.length > 0 
        ? connectedVoltages.reduce((sum, d) => sum + d.voltage, 0) / connectedVoltages.length 
        : 0;
      
      document.getElementById('connectedCount').textContent = connectedDevices;
      document.getElementById('criticalCount').textContent = criticalDevices;
      document.getElementById('avgVoltage').textContent = connectedDevices > 0 ? avgVoltage.toFixed(2) + 'V' : '--';
      
      // Update last update time
      document.getElementById('lastUpdate').textContent = new Date().toLocaleTimeString();
    }
    
    function manualRefresh() {
  // First request battery status from all slaves
  fetch('/requestBattery', { 
    method: 'GET',
    cache: 'no-cache'
  })
    .then(response => {
      console.log('Battery request sent to slaves');
    })
    .catch(error => {
      console.error('Error requesting battery status:', error);
    });
  
  // Wait 500ms for slaves to respond, then fetch updated data
  setTimeout(() => {
    fetchBatteryData();
  }, 500);
}
  </script>
</head>
<body>
  <div class="container">
    <h1>Battery Management Dashboard</h1>
    
    <!-- Summary Panel -->
    <div class="summary-panel">
      <div class="summary-card">
        <div class="summary-title">Connected Devices</div>
        <div class="summary-value" id="connectedCount">--</div>
      </div>
      <div class="summary-card">
        <div class="summary-title">Critical Batteries</div>
        <div class="summary-value" style="color: #e74c3c;" id="criticalCount">--</div>
      </div>
    </div>
    
    <!-- Set 1 -->
    <div class="system-section">
      <h2>ShuttleRun Set A</h2>
      
      <div class="battery-grid">
        <!-- Master 1 -->
        <div class="battery-card master" id="card-1">
          <div class="device-label">Master</div>
          <div class="device-id">Device #1</div>
          <div class="battery-container">
            <div class="battery-body">
              <div class="battery-level" id="batteryLevel-1" style="height: 0%">
                <div class="battery-shine"></div>
              </div>
            </div>
            <div class="battery-tip"></div>
          </div>
          <div class="percentage-display" id="percentage-1">--%</div>
          <div class="voltage-display" id="voltage-1">--V</div>
          <div class="status-badge status-disconnected" id="status-1">Disconnected</div>
        </div>
        
        <!-- Slaves 2-5 -->
        <div class="battery-card slave" id="card-2">
          <div class="device-label">Cone 1</div>
          <div class="device-id">Device #2</div>
          <div class="battery-container">
            <div class="battery-body">
              <div class="battery-level" id="batteryLevel-2" style="height: 0%">
                <div class="battery-shine"></div>
              </div>
            </div>
            <div class="battery-tip"></div>
          </div>
          <div class="percentage-display" id="percentage-2">--%</div>
          <div class="voltage-display" id="voltage-2">--V</div>
          <div class="status-badge status-disconnected" id="status-2">Disconnected</div>
        </div>
        
        <div class="battery-card slave" id="card-3">
          <div class="device-label">Cone 2</div>
          <div class="device-id">Device #3</div>
          <div class="battery-container">
            <div class="battery-body">
              <div class="battery-level" id="batteryLevel-3" style="height: 0%">
                <div class="battery-shine"></div>
              </div>
            </div>
            <div class="battery-tip"></div>
          </div>
          <div class="percentage-display" id="percentage-3">--%</div>
          <div class="voltage-display" id="voltage-3">--V</div>
          <div class="status-badge status-disconnected" id="status-3">Disconnected</div>
        </div>
        
        <div class="battery-card slave" id="card-4">
          <div class="device-label">Cone 3</div>
          <div class="device-id">Device #4</div>
          <div class="battery-container">
            <div class="battery-body">
              <div class="battery-level" id="batteryLevel-4" style="height: 0%">
                <div class="battery-shine"></div>
              </div>
            </div>
            <div class="battery-tip"></div>
          </div>
          <div class="percentage-display" id="percentage-4">--%</div>
          <div class="voltage-display" id="voltage-4">--V</div>
          <div class="status-badge status-disconnected" id="status-4">Disconnected</div>
        </div>
        
        <div class="battery-card slave" id="card-5">
          <div class="device-label">Cone 4</div>
          <div class="device-id">Device #5</div>
          <div class="battery-container">
            <div class="battery-body">
              <div class="battery-level" id="batteryLevel-5" style="height: 0%">
                <div class="battery-shine"></div>
              </div>
            </div>
            <div class="battery-tip"></div>
          </div>
          <div class="percentage-display" id="percentage-5">--%</div>
          <div class="voltage-display" id="voltage-5">--V</div>
          <div class="status-badge status-disconnected" id="status-5">Disconnected</div>
        </div>
      </div>
    </div>
    
    <!-- System 2 -->
    <div class="system-section">
      <h2>ShuttleRun Set B</h2>
      
      <div class="battery-grid">
        <!-- Master 6 -->
        <div class="battery-card master" id="card-6">
          <div class="device-label">Master</div>
          <div class="device-id">Device #6</div>
          <div class="battery-container">
            <div class="battery-body">
              <div class="battery-level" id="batteryLevel-6" style="height: 0%">
                <div class="battery-shine"></div>
              </div>
            </div>
            <div class="battery-tip"></div>
          </div>
          <div class="percentage-display" id="percentage-6">--%</div>
          <div class="voltage-display" id="voltage-6">--V</div>
          <div class="status-badge status-disconnected" id="status-6">Disconnected</div>
        </div>
        
        <!-- Slaves 7-10 -->
        <div class="battery-card slave" id="card-7">
          <div class="device-label">Cone 1</div>
          <div class="device-id">Device #7</div>
          <div class="battery-container">
            <div class="battery-body">
              <div class="battery-level" id="batteryLevel-7" style="height: 0%">
                <div class="battery-shine"></div>
              </div>
            </div>
            <div class="battery-tip"></div>
          </div>
          <div class="percentage-display" id="percentage-7">--%</div>
          <div class="voltage-display" id="voltage-7">--V</div>
          <div class="status-badge status-disconnected" id="status-7">Disconnected</div>
        </div>
        
        <div class="battery-card slave" id="card-8">
          <div class="device-label">Cone 2</div>
          <div class="device-id">Device #8</div>
          <div class="battery-container">
            <div class="battery-body">
              <div class="battery-level" id="batteryLevel-8" style="height: 0%">
                <div class="battery-shine"></div>
              </div>
            </div>
            <div class="battery-tip"></div>
          </div>
          <div class="percentage-display" id="percentage-8">--%</div>
          <div class="voltage-display" id="voltage-8">--V</div>
          <div class="status-badge status-disconnected" id="status-8">Disconnected</div>
        </div>
        
        <div class="battery-card slave" id="card-9">
          <div class="device-label">Cone 3</div>
          <div class="device-id">Device #9</div>
          <div class="battery-container">
            <div class="battery-body">
              <div class="battery-level" id="batteryLevel-9" style="height: 0%">
                <div class="battery-shine"></div>
              </div>
            </div>
            <div class="battery-tip"></div>
          </div>
          <div class="percentage-display" id="percentage-9">--%</div>
          <div class="voltage-display" id="voltage-9">--V</div>
          <div class="status-badge status-disconnected" id="status-9">Disconnected</div>
        </div>
        
        <div class="battery-card slave" id="card-10">
          <div class="device-label">Cone 4</div>
          <div class="device-id">Device #10</div>
          <div class="battery-container">
            <div class="battery-body">
              <div class="battery-level" id="batteryLevel-10" style="height: 0%">
                <div class="battery-shine"></div>
              </div>
            </div>
            <div class="battery-tip"></div>
          </div>
          <div class="percentage-display" id="percentage-10">--%</div>
          <div class="voltage-display" id="voltage-10">--V</div>
          <div class="status-badge status-disconnected" id="status-10">Disconnected</div>
        </div>
      </div>
    </div>
    <!-- Refresh status Button -->    
    <button class="refresh-btn" onclick="manualRefresh()">Refresh</button>
    <!-- Return to game Button -->
    <button class="battery-btn" onclick="window.location.href='/'">Return to Game</button>
    
    
    <div class="last-update">
      Last updated: <span id="lastUpdate">--</span>
    </div>
  </div>
</body>
</html>
)rawliteral";

#endif